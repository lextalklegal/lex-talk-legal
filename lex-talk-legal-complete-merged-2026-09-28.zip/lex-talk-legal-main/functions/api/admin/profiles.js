import { json, adminEmail, text, safeUrl, list, requestOriginAllowed, profileData } from "../../_lib.js";

function deny(){ return json({ok:false,error:"Admin authentication required."},401,{"WWW-Authenticate":"Cloudflare Access"}); }

export async function onRequestGet(context) {
  const email=adminEmail(context.request,context.env); if(!email) return deny();
  if(!context.env.DB) return json({ok:false,error:"D1 database binding is not configured."},503);
  const url=new URL(context.request.url); const status=text(url.searchParams.get("status"),30) || "pending"; const allowed=['pending','under_review','approved','rejected','suspended','all']; if(!allowed.includes(status)) return json({ok:false,error:"Invalid status."},400);
  const limit=Math.min(Math.max(parseInt(url.searchParams.get('limit')||'50',10)||50,1),100);
  const q=text(url.searchParams.get('q'),80);
  let query=`SELECT * FROM profiles`; const binds=[]; const where=[];
  if(status!=='all'){where.push('status=?');binds.push(status);} if(q){where.push('(full_name LIKE ? OR enrolment_number LIKE ? OR state_bar_council LIKE ? OR city LIKE ?)');const like=`%${q}%`;binds.push(like,like,like,like);}
  if(where.length) query+=' WHERE '+where.join(' AND '); query+=` ORDER BY created_at DESC LIMIT ?`;binds.push(limit);
  const rows=await context.env.DB.prepare(query).bind(...binds).all();
  return json({ok:true,admin:email,profiles:(rows.results||[]).map(profileData)});
}

export async function onRequestPatch(context) {
  const email=adminEmail(context.request,context.env); if(!email) return deny();
  if(!requestOriginAllowed(context.request)) return json({ok:false,error:"Invalid request origin."},403);
  if(!context.env.DB) return json({ok:false,error:"D1 database binding is not configured."},503);
  let body; try{body=await context.request.json();}catch{return json({ok:false,error:'Invalid JSON.'},400);}
  const id=text(body.id,80); const action=text(body.action,30); if(!id||!action) return json({ok:false,error:'Profile ID and action are required.'},400);
  const existing=await context.env.DB.prepare(`SELECT * FROM profiles WHERE id=? LIMIT 1`).bind(id).first(); if(!existing) return json({ok:false,error:'Profile not found.'},404);
  const now=new Date().toISOString(); let newStatus=existing.status; let extra={};
  if(action==='approve'){newStatus='approved';extra.published_at=existing.published_at||now;}
  else if(action==='reject'){newStatus='rejected';extra.published_at=null;}
  else if(action==='suspend'){newStatus='suspended';extra.published_at=null;}
  else if(action==='restore'){newStatus='approved';extra.published_at=existing.published_at||now;}
  else if(action==='review'){newStatus='under_review';}
  else if(action==='note'){extra.review_notes=text(body.review_notes,1500);}
  else if(action==='update'){
    const patch={};
    if(body.full_name!==undefined) patch.full_name=text(body.full_name,100);
    if(body.state_bar_council!==undefined) patch.state_bar_council=text(body.state_bar_council,160);
    if(body.enrolment_number!==undefined) patch.enrolment_number=text(body.enrolment_number,80);
    if(body.enrolment_year!==undefined) patch.enrolment_year=body.enrolment_year?Number(body.enrolment_year):null;
    if(body.qualification!==undefined) patch.qualification=text(body.qualification,160);
    if(body.city!==undefined) patch.city=text(body.city,80);
    if(body.state!==undefined) patch.state=text(body.state,80);
    if(body.bio!==undefined) patch.bio=text(body.bio,1400);
    if(body.practice_areas!==undefined) patch.practice_areas_json=JSON.stringify(list(body.practice_areas,12,70));
    if(body.courts!==undefined) patch.courts_json=JSON.stringify(list(body.courts,12,90));
    if(body.professional_website!==undefined) patch.professional_website=safeUrl(body.professional_website,[]);
    if(body.photo_url!==undefined) patch.photo_url=safeUrl(body.photo_url,[]);
    if(body.linkedin_url!==undefined) patch.linkedin_url=safeUrl(body.linkedin_url,['www.linkedin.com','linkedin.com','in.linkedin.com']);
    const keys=Object.keys(patch); if(!keys.length) return json({ok:false,error:'No editable fields supplied.'},400);
    const set=keys.map(k=>`${k}=?`).join(', '); const binds=keys.map(k=>patch[k]); binds.push(now,id);
    await context.env.DB.prepare(`UPDATE profiles SET ${set}, updated_at=? WHERE id=?`).bind(...binds).run();
    await context.env.DB.prepare(`INSERT INTO audit_log (id,profile_id,actor_type,actor_email,action,details_json,created_at) VALUES (?,?,?,?,?,?,?)`).bind(crypto.randomUUID(),id,'admin',email,'updated',JSON.stringify(patch),now).run();
    return json({ok:true,message:'Profile updated. Review status was not changed automatically.'});
  } else return json({ok:false,error:'Unsupported action.'},400);
  const updates=['status=?','updated_at=?']; const values=[newStatus,now];
  if(Object.prototype.hasOwnProperty.call(extra,'published_at')){updates.push('published_at=?');values.push(extra.published_at);}
  if(Object.prototype.hasOwnProperty.call(extra,'review_notes')){updates.push('review_notes=?');values.push(extra.review_notes);}
  values.push(id); await context.env.DB.prepare(`UPDATE profiles SET ${updates.join(', ')} WHERE id=?`).bind(...values).run();
  await context.env.DB.prepare(`INSERT INTO audit_log (id,profile_id,actor_type,actor_email,action,details_json,created_at) VALUES (?,?,?,?,?,?,?)`).bind(crypto.randomUUID(),id,'admin',email,action,JSON.stringify(extra),now).run();
  return json({ok:true,status:newStatus});
}
